package com.thbs.springdemo.driver;

public class AppMain {
    public static void main(String[] args) {
        System.out.println("Hello");
    }
}
