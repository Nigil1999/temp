package com.thbs.springdemo.service;

import com.thbs.springdemo.model.Employee;
import com.thbs.springdemo.repository.DepartmentRepository;
import com.thbs.springdemo.repository.EmployeeRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class EmployeeService {

    @Autowired
    EmployeeRepository employeeRepository;

    @Autowired
    DepartmentRepository departmentRepository;

    private final Logger LOG = LoggerFactory.getLogger(this.getClass());

    public List<Employee> empList= new ArrayList<>();

    {
        empList.add(new Employee(101,"Ram", 45000));
        empList.add(new Employee(102,"Shiva", 50000));
        empList.add(new Employee(103,"Krishna", 60000));
    }

    public List<Employee> getAllEmployees(){
        LOG.info("getAllEmployees");
        return employeeRepository.findAll();
    }
    public Employee getEmployeeById(int eId){
        LOG.info("getAllEmployeeById");
        return employeeRepository.findById(eId).get();
    }

    public List<Employee> getEmployeeByName(String empName){
        LOG.info("getAllEmployeeByName");
        return employeeRepository.findByempName(empName);
    }

    public List<Employee> getEmployeeByCity(String city){
        LOG.info("getAllEmployeeByCity");
        return employeeRepository.findByDepartment_City(city);
    }

    public List<Employee> getEmployeeBySalary(double salary){
        LOG.info("getAllEmployeeByName");
        return employeeRepository.findBysalary(salary);
    }

    public Employee addEmployee(Employee emp){
        LOG.info("addEmployee");

        if(emp.getDepartment() != null){
            if(departmentRepository.existsById(emp.getDepartment().getDepartmentId())) {
                LOG.info("Employee Added Successfully");
                return employeeRepository.save(emp);
            }
        }
        LOG.info("Employee was not added because given department does not exists");
        return null;
    }

    public Employee updateEmployee(Employee emp){
        LOG.info("updateEmployee");
        return employeeRepository.save(emp);
    }

    public Employee deleteEmployee(int eid){
        //empList.add(emp);
        LOG.info("deleteEmployee "+ eid);
        employeeRepository.deleteById(eid);
        return null;
    }



}
