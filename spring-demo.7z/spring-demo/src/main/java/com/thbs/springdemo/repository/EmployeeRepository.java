package com.thbs.springdemo.repository;

import com.thbs.springdemo.model.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee,Integer> {

    // Syntax: public abstract List<className> findByfieldName(String name);
    public abstract List<Employee> findByempName(String empName);

    //Which employees work in the city 'Tirupur'

    public abstract List<Employee> findByDepartment_City(String city);



    //Written in JPQL - Java Persistence Query Language

    //JPQL
    //@Query("select e from Employee e where e.salary = ?1")

    //SQL
    //@Query(value = "select * from Employee where salary = ?1")
    public abstract List<Employee> findBysalary(double salary);

    //JPQL
    //@Query("select e from Employee e where e.salary between ?1 and ?2") //SQL
    //public abstract List<Employee> findBysalaryBetween(double minSalary, double maxSalary);

    //public abstract List<Employee> findBysalaryGreaterThan(double salary);

    //public abstract List<Employee> findBysalaryLessThan(double salary);


}
