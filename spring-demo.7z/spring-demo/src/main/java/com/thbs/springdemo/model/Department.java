package com.thbs.springdemo.model;

import org.springframework.boot.context.properties.ConstructorBinding;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "department")
public class Department {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int departmentId;

    @Column(name = "departmentName")
    private String departmentName;
    @Column(name = "city")
    private String city;

    public Department() {
        super();
    }

    public Department(String departmentName, String city) {
        this.departmentName = departmentName;
        this.city = city;
    }

    public Department(int departmentId, String departmentName, String city) {
        this.departmentId = departmentId;
        this.departmentName = departmentName;
        this.city = city;
    }

    public int getDepartmentId() {
        return departmentId;
    }

    public void setDepartment_id(int departmentId) {
        this.departmentId = departmentId;
    }

    public String getDepartmentName() {
        return departmentName;
    }

    public void setDepartment_name(String departmentName) {
        this.departmentName = departmentName;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    @Override
    public String toString() {
        return "Department{" +
                "departmentId=" + departmentId +
                ", departmentName='" + departmentName + '\'' +
                ", city='" + city + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Department that = (Department) o;
        return departmentId == that.departmentId && Objects.equals(departmentName, that.departmentName) && Objects.equals(city, that.city);
    }

    @Override
    public int hashCode() {
        return Objects.hash(departmentId, departmentName, city);
    }
}
