package com.thbs.springdemo.controller;

import com.thbs.springdemo.model.Employee;
import com.thbs.springdemo.service.EmployeeService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    private final Logger LOG= LoggerFactory.getLogger(this.getClass());

    @GetMapping("/empbyid/{eid}")
    public Employee emp(@PathVariable(name = "eid") int eid) {
        //System.out.println("emp");
        //int eid = 101;
        LOG.info("emp " + eid);
        return employeeService.getEmployeeById(eid);
    }

    @GetMapping("/empbyname/{empName}")
    public List<Employee> empName(@PathVariable(name = "empName") String empName) {
        //System.out.println("emp");
        //int eid = 101;
        LOG.info("empbyname " + empName);
        return employeeService.getEmployeeByName(empName);
    }

    @GetMapping("/empbycity/{city}")
    public List<Employee> empCity(@PathVariable(name = "city") String city) {
        //System.out.println("emp");
        //int eid = 101;
        LOG.info("empbycity " + city);
        return employeeService.getEmployeeByCity(city);
    }

    @GetMapping("/empbysalary/{salary}")
    public List<Employee> empSalary(@PathVariable(name = "salary") double salary) {
        //System.out.println("emp");
        //int eid = 101;
        LOG.info("empbysalary " + salary);
        return employeeService.getEmployeeBySalary(salary);
    }

    @GetMapping("/emplist")
    public List<Employee> empList() {
        //System.out.println("empList");
        LOG.info("emplist");
        return employeeService.getAllEmployees();
    }

    @PostMapping("/addemp")
    public Employee addEmp(@RequestBody Employee emp) {
        //System.out.println("addemp");
        LOG.info("addemp");
        return employeeService.addEmployee(emp);
    }

    @PutMapping("/updateemp")
    public Employee updateEmp(@RequestBody Employee emp) {
        //System.out.println("updateemp");
        LOG.info("updateemp");
        return employeeService.updateEmployee(emp);
    }
    @DeleteMapping("/deleteemp/{eid}")
    public Employee deleteEmp(@PathVariable(name = "eid") int eid) {
        //System.out.println("deleteemp");
        LOG.info("deleteemp "+"eid");
        return employeeService.deleteEmployee(eid);
    }

}
