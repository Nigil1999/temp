package com.thbs.springdemo.model;

import javax.persistence.*;

@Entity
@Table(name = "employee") // If this annotation is not present then table will create in name of Class
public class Employee {

    @Id  //Works as a Primary Key
    @GeneratedValue(strategy = GenerationType.AUTO)  //Sequence to auto generate value for Primary Key like 1,2,3,4,5,.....etc. or instead of strategy we can use generator to specify starting value.
    private int empId;
    @Column(name = "empName") //If this annotation is not present then it will take name of variable
    private String empName;
    @Column(name = "salary")
    private double salary;

    @ManyToOne
    @JoinColumn(name = "departmentId")
    private Department department;

    public Employee(int empId, String empName, double salary, Department department) {
        this.empId = empId;
        this.empName = empName;
        this.salary = salary;
        this.department = department;
    }

    public Employee() {
        super();
    }

    public Employee(String empName, double salary) {
        this.empName = empName;
        this.salary = salary;
    }

    public Employee(int empId, String empName, double salary) {
        this.empId = empId;
        this.empName = empName;
        this.salary = salary;
    }

    public int getEmpId() {
        return empId;
    }

    public void setEmpId(int empId) {
        this.empId = empId;
    }

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "empId=" + empId +
                ", empName='" + empName + '\'' +
                ", salary=" + salary +
                ", department=" + department +
                '}';
    }
}
