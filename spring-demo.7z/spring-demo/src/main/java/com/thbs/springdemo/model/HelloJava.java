package com.thbs.springdemo.model;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloJava {

    @GetMapping("/hello")
    public String hello() {
        System.out.println("hello");
        return "Hello World!";
    }
    @GetMapping("/hi")
    public String hi() {
        System.out.println("hi");
        return "Hi Welcome To Spring Boot Demo";
    }
    @GetMapping("/*")
    public String page404() {
        System.out.println("Page 404");
        return "The Page You Are Looking For Not Found!";
    }
}
